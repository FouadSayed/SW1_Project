import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Slot {
    private double length;
    String Arrival ;
    public static int identifier;
    private Vehicle v = null;
    private double width;

    Slot( )
    {
        identifier++;
    }

    public void setV(Vehicle v) {
        this.v = v;
    }

    public Vehicle getV() {
        return v;
    }

    void SetLength(double length)
    {
        this.length = length;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double GetLength(){
        return length;
    }
    public double GetWidth(){
        return width;
    }

    public void setArrival(String arrival) {
        Arrival = arrival;
    }

    public String getArrival() {
        return Arrival;
    }

    public static int getIdentifier() {
        return identifier;
    }
    public  String  calculateTime()
    {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        String str = dtf.format(now);
        return str;
    }

    public String ParkOut(int Key){
        String Depart = Garage.getInstance().GetCurrentSlot(Key).calculateTime();
        Garage.getInstance().GetCurrentSlot(Key).setV(null);
        return Depart;
    }


}
