import java.util.*;

public class Main {

    static  Scanner sc= new Scanner(System.in);
    static int f =0;
    public static void main(String[] args) {
        monitor s;
        s = new monitor();
        s.Start();
    }






}
