import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class monitor {

    public void Start(){
        Scanner s= new Scanner(System.in);
        System.out.println("Welcome to FCI Garage System\n");
        System.out.println("Enter the number of slots: ");
        int size = s.nextInt();
        Garage.getInstance().SetSlotSize(size);

        for(int i = 0 ; i < Garage.getInstance().GetSize() ; i++)
        {
            System.out.println("Enter the dimensions of each slot: ");
            double length =0.0  , width = 0.0;
            length = s.nextDouble();
            width = s.nextDouble();
            Garage.getInstance().SetSlot(i , length , width);
        }


        boolean end = true;
        int Choice ;

        int c = 0;
        System.out.println("please choose your park in configuration");
        System.out.println("1.First come first served");
        System.out.println("2.Best Fit");
        c = s.nextInt();

        while(end)
        {
            System.out.println("0.Exit");
            System.out.println("1.Park In");
            System.out.println("2.Park out");
            System.out.println("3.Calculate fees");
            System.out.println("4.Calculate Total income");
            System.out.println("5.Display available slots");
            System.out.println("please enter the operation");
            Choice =s.nextInt();

                switch (Choice) {

                    case 1:
                        boolean IsFull = false;

                        if (c == 1) IsFull = Garage.getInstance().f.ParkIn(InputVehicle());
                        else if (c == 2) IsFull = Garage.getInstance().b.ParkIn(InputVehicle());
                        if (IsFull == true) System.out.println("car parked succesfully.");
                        else System.out.println("Sorry garage Is Full.");
                        break;
                    case 2:
                        int key = 0;
                        System.out.println("please enter the slot ID");
                        key = s.nextInt();
                        Garage.getInstance().GetCurrentSlot(key).ParkOut(key);

                        break;

                    case 3:
                        System.out.println("Please enter slot number");
                        int num = 0;
                        num = s.nextInt();
                        int result = Garage.getInstance().Fees(Garage.getInstance().GetCurrentSlot(num).getArrival(), Garage.getInstance().GetCurrentSlot(num).ParkOut(num));
                        System.out.println("The fees equals: " + result +" ");
                        TotalIncome.getInst().TotalFees.add(result);
                        break;
                    case 4:
                        int Total = 0;
                        for (int i = 0; i < TotalIncome.getInst().TotalFees.size(); i++) {
                            Total += TotalIncome.getInst().TotalFees.get(i);
                        }
                        System.out.println("The total Income equal: " + Total + " ");
                        break;
                    case 5:
                        Garage.getInstance().Display();
                        break;
                    case 0 :
                        System.exit(0);
                    default:
                        System.out.println("enter a valid number");

                }




        }
}



    public Vehicle InputVehicle(){
        String Model;
        int ID , year;
        double l ,w;
        Vehicle v1;
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter the Model Name :- ");
        Model= sc.nextLine();
        System.out.println("Enter the Vehicle ID :- ");
        ID= sc.nextInt();
        System.out.println("Enter the Model Year :- ");
        year= sc.nextInt();
        System.out.println("Enter the car length :- ");
        l = sc.nextDouble();
        System.out.println("Enter the car width :- ");
        w = sc.nextDouble();
        v1 = new Vehicle(Model,ID,year , l , w);
        return v1;
    }
}
