import java.util.Scanner;

public interface Configuration {
    public boolean ParkIn(Vehicle car);

}





