import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
public class Vehicle {

    String ModelName;
    int id , ModelYear ;
    double length , width;

    Vehicle(String model,int id,int year , double length , double width){
        this.ModelName =model;
        this.id=id;
        this.ModelYear =year;
        this.length = length;
        this.width = width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getWidth() {
        return width;
    }

    public double getLength() {
        return length;
    }










}
