public class FCFS implements Configuration {

    public boolean ParkIn(Vehicle car) {

        for(int i = 0 ; i<Garage.getInstance().GetSize();i++){
            if(Garage.getInstance().GetCurrentSlot(i).getV() == null)
            {
                if((car.getLength()<=Garage.getInstance().GetCurrentSlot(i).GetLength()) &&  (car.getWidth()<=Garage.getInstance().GetCurrentSlot(i).GetWidth()))
                {
                    Garage.getInstance().GetCurrentSlot(i).setV(car);
                    Garage.getInstance().GetCurrentSlot(i).setArrival(Garage.getInstance().GetCurrentSlot(i).calculateTime());
                    return true;
                }
            }
        }
        return false;
    }


}
