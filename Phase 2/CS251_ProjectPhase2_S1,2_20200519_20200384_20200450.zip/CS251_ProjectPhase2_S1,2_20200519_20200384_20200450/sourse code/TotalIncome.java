import java.util.ArrayList;

public  class TotalIncome {

    private static TotalIncome inst;
    public  ArrayList<Integer> TotalFees = new ArrayList<>();
    private TotalIncome(){}

    public static TotalIncome getInst() {
        if(inst == null)
            inst = new TotalIncome();
        return inst;
    }
}
