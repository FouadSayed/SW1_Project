import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Garage {

    private static Garage instance;
    public FCFS f;
    public BestFit b;

    private int size;
    public Slot[] slots;
    private Garage( ){
        f = new FCFS();
        b = new BestFit();
    }
    public Slot GetCurrentSlot(int i)
    {
        return slots[i];
    }

    public static Garage getInstance() {
        if(instance == null)
            instance = new Garage();
        return instance;
    }

    public void SetSlotSize(int size){
        this.size = size;
        slots = new Slot[size];

    }

    public void SetSlot(int i , double l , double w ){
        slots[i]= new Slot();
        slots[i].SetLength(l);
        slots[i].setWidth(w);
    }
    public int GetSize(){return size;}





    public  int Fees(String start_date,
                           String end_date)
    {
        SimpleDateFormat sdf
                = new SimpleDateFormat(
                "dd-MM-yyyy HH:mm:ss");
        int counter =0;
        try {
            Date d1 = sdf.parse(start_date);
            Date d2 = sdf.parse(end_date);

            long difference_In_Time
                    = d2.getTime() - d1.getTime();
            long difference_In_Seconds
                    = (difference_In_Time
                    / 1000)
                    % 60;

            long difference_In_Minutes
                    = (difference_In_Time
                    / (1000 * 60))
                    % 60;

            long difference_In_Hours
                    = (difference_In_Time
                    / (1000 * 60 * 60))
                    % 24;

            if((difference_In_Minutes >=1) || (difference_In_Seconds >= 1) )
            {
                counter += 5;
                if(difference_In_Hours >=1)
                {
                    counter += difference_In_Hours * 5;
                }
            }
        }
        catch (ParseException e) {
            e.printStackTrace();
        }
        return counter;
    }

   public void Display(){
       for(int i = 0 ; i < Garage.getInstance().GetSize(); i++)
       {
           if(Garage.getInstance().GetCurrentSlot(i).getV() == null)
           {
               System.out.print("slot ");

               System.out.print( i +1 );
               System.out.println(" is empty");
           }
       }
   }


}
